package edu.uob;

public class ArtefactEntity extends GameEntity{
    public ArtefactEntity(String name, String description) {
        super(name, description);
    }
}
