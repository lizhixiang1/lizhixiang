package edu.uob;

public class FurnitureEntity extends GameEntity{
    public FurnitureEntity(String name, String description) {
        super(name, description);
    }
}
