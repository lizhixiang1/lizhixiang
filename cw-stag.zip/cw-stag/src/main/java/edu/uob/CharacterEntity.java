package edu.uob;

public class CharacterEntity extends GameEntity{
    public CharacterEntity(String name, String description) {
        super(name, description);
    }
}
